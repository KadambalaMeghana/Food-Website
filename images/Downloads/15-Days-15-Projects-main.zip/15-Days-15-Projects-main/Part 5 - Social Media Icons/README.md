# Part 5 - Social Media Icons

[View Demo](https://code-architects.github.io/15-Days-15-Projects/Part%205%20-%20Social%20Media%20Icons)

![Preview for Social Media Icons](./preview.png)