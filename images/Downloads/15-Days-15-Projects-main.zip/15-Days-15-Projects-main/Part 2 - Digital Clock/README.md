# Part 2 - Digital Clock
[View Demo](https://code-architects.github.io/15-Days-15-Projects/Part%202%20-%20Digital%20Clock/)

![Preview for Digital Clock](./preview.png)