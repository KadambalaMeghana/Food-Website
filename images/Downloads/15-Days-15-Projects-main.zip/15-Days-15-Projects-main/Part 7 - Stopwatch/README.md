# Part 7 - Stopwatch

[View Demo](https://code-architects.github.io/15-Days-15-Projects/Part%207%20-%20Stopwatch)

![Preview for Stopwatch](./preview.png)