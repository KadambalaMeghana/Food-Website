# Part 11 - Vertical Navigation Menu

[View Demo](https://code-architects.github.io/15-Days-15-Projects/Part%2011%20-%20Vertical%20Navigation%20Menu/)

![Preview for Vertical Navigation Menu](./preview.png)
