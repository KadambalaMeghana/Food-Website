# Part 1 - Calculator
[View Demo](https://code-architects.github.io/15-Days-15-Projects/Part%201%20-%20Calculator/)

![Preview for Calculator](./preview.png)
