# Part 14 - Google Clone

[View Demo](https://code-architects.github.io/15-Days-15-Projects/Part%2014%20-%20Google%20Clone/)

![Preview for Google Clone](./preview.png)