# Part 8 - Profile Card

[View Demo](https://code-architects.github.io/15-Days-15-Projects/Part%208%20-%20Profile%20Card)

![Preview for Profile Card](./preview.png)