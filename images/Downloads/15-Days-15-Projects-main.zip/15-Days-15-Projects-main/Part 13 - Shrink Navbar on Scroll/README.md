# Part 13 - Shrink Navbar on Scroll

[View Demo](https://code-architects.github.io/15-Days-15-Projects/Part%2013%20-%20Shrink%20Navbar%20on%20Scroll/)

![Preview for Shrink Navbar on Scroll](./preview.png)