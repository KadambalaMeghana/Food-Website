# Part 4 - Rock Paper and Scissors

[View Demo](https://code-architects.github.io/15-Days-15-Projects/Part%204%20-%20Rock%20Paper%20and%20Scissors/)

![Preview for Rock Paper Scissors](./preview.png)