# Part 3 - To Do List

[View Demo](https://code-architects.github.io/15-Days-15-Projects/Part%203%20-%20To%20Do%20List/)

![Preview for To Do List](./preview.png)