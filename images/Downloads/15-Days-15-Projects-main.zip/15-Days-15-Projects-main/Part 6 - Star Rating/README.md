# Part 6 - Star Rating

[View Demo](https://code-architects.github.io/15-Days-15-Projects/Part%206%20-%20Star%20Rating)

![Preview for Star Rating](./preview.png)