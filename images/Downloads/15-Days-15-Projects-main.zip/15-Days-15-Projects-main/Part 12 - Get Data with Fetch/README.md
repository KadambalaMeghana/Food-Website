# Part 12 - Get Data with Fetch

[View Demo](https://code-architects.github.io/15-Days-15-Projects/Part%2012%20-%20Get%20Data%20with%20Fetch)

![Preview for Get Data with Fetch](./preview.png)